const { OpenAI } = require('openai');  // Importation correcte pour OpenAI v3.x
const fs = require('fs');
const path = require('path');

// Configuration de l'API OpenAI
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,  // Utilisation de la clé API depuis .env
});

async function filterCvsWithGPT(criteria, cvs) {
  try {
    // Construction du prompt pour GPT-5 en utilisant les critères et les CVs
    const prompt = `
      Voici les critères de sélection :
      - Diplôme : ${criteria.diplome}
      - Expérience : ${criteria.experience} années
      - Fonction : ${criteria.fonction}
      
      Voici les CVs à évaluer :
      ${cvs.map(cv => `Nom: ${cv.nom}\nDiplôme: ${cv.diplome}\nExpérience: ${cv.experience}\nFonction: ${cv.fonction}\n`).join('\n')}
      
      Filtre les CVs qui correspondent le mieux aux critères.
    `;
    
    // Appel à l'API OpenAI pour générer les résultats filtrés
    const response = await openai.chat.completions.create({
      model: 'gpt-5',
      messages: [{ role: 'user', content: prompt }],
    });

    return response.choices[0].message.content.trim();
  } catch (error) {
    console.error('Erreur GPT-5:', error);
    throw new Error('Erreur lors du filtrage des CVs');
  }
}

module.exports = { filterCvsWithGPT };
