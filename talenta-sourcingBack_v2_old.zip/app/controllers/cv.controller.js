const { filterCvsWithGPT } = require('../services/cv.service');

// Route pour filtrer les CVs
exports.filterCvs = async (req, res) => {
  try {
    const { criteria, cvs } = req.body; // Récupérer les critères et les CVs depuis la requête
    const filteredCvs = await filterCvsWithGPT(criteria, cvs);  // Appeler le service GPT-5
    res.json({ filteredCvs });  // Retourner les CVs filtrés
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
