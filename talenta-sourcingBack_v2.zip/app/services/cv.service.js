require('dotenv').config();
const { OpenAI } = require("openai");
const axios = require("axios");
const fs = require("fs");
const path = require("path");

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Télécharge un PDF depuis une URL (ex : http://localhost:3000/cv/x.pdf)
async function downloadPdf(url) {
  const response = await axios.get(url, { responseType: "arraybuffer" });
  return Buffer.from(response.data);
}

// Lit un PDF via OpenAI (analyse texte)
async function extractTextFromPdf(pdfBuffer) {
  const response = await openai.responses.create({
    model: "gpt-4.1", // Vision + PDF compatible
    input: [
      {
        role: "user",
        content: [
          { type: "input_text", text: "Extract all text from this PDF CV." },
          {
            type: "input_file",
            file: {
              name: "cv.pdf",
              data: pdfBuffer.toString("base64")
            }
          }
        ]
      }
    ]
  });

  return response.output_text;
}

// Tri de CV basé sur analyse réelle du PDF
async function filterCvsWithGPT(criteria, cvs) {
  try {
    const { diplome, experienceMin, fonctions, customPrompt } = criteria;

    // 1) Lire tous les CV (PDF)
    const cvTexts = {};

    // Pour chaque candidat, récupérer et analyser le PDF
    for (const cv of cvs) {
	  console.log('Candidat:', cv.content); 
	  // Vérification si cv.cvUrl est bien défini et non null
      if (!cv.cvUrl) {
        console.log(`Aucun CV URL pour le candidat ${cv.id}`);
        continue; // On passe au candidat suivant si cvUrl est null ou vide
      }
	  
      //if (!cv.cvUrl) continue; // S'assurer qu'un cvUrl existe

      // Construire l'URL du CV à partir de BASE_URL_BACK et cvUrl
      const urlPdf = process.env.BASE_URL_BACK + cv.cvUrl;

      console.log("Téléchargement PDF :", urlPdf);
      const pdfBuffer = await downloadPdf(urlPdf);

      console.log("Analyse du PDF via GPT...");
      const text = await extractTextFromPdf(pdfBuffer);

      // Stocker le texte du CV dans cvTexts
      cvTexts[cv.id] = text;
    }

    // 2) GPT : Application des critères
    const systemPrompt = customPrompt || `
Tu es un système de recrutement.
Tu dois lire le texte des CV bruts (PDF analysés).
Tu appliques le filtre sur :

- Diplôme : ${diplome}
- Expérience minimale : ${experienceMin} ans
- Fonctions requises : ${(fonctions || []).join(", ")}

Retourne STRICTEMENT ce JSON :

{
  "retenus": [{ "id": <id>, "raison": "<texte>" }],
  "rejetes": [{ "id": <id>, "raison": "<texte>" }]
}
`;

    const userPrompt = `
Voici les CV analysés :

${JSON.stringify(cvTexts, null, 2)}
`;

    const response = await openai.responses.create({
      model: "gpt-4.1",
      input: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt }
      ]
    });

    const out = response.output_text;

    let parsed;
    try {
      parsed = JSON.parse(out);
    } catch {
      parsed = { raw: out };
    }

    return parsed;

  } catch (err) {
    console.error("Erreur GPT (PDF):", err);
    throw new Error("Erreur analyse PDF CV");
  }
}

module.exports = { filterCvsWithGPT };
